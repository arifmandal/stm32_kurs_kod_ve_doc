#include "stm32f10x.h"                  // Device header
#include "stm32f10x_tim.h"              // Keil::Device:StdPeriph Drivers:TIM

void gpioConfig(){
   
   GPIO_InitTypeDef GPIOInitStructure;
   RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);//A port clock aktif
	
   GPIOInitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
   GPIOInitStructure.GPIO_Pin = GPIO_Pin_0 |GPIO_Pin_1;//tim2 channel1 
   GPIOInitStructure.GPIO_Speed = GPIO_Speed_50MHz;
   
   GPIO_Init(GPIOA, &GPIOInitStructure);

}


void timerConfig(){
   TIM_TimeBaseInitTypeDef TIMERInitStructure;
   
   RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);
   
   TIMERInitStructure.TIM_Prescaler = 100;
   TIMERInitStructure.TIM_Period = 4799;
   TIMERInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;
   TIMERInitStructure.TIM_CounterMode = TIM_CounterMode_Up;
   TIM_TimeBaseInit(TIM2, &TIMERInitStructure);
   TIM_Cmd(TIM2, ENABLE);

}

void pwmConfig(uint16_t timPulse){
	
   TIM_OCInitTypeDef TIM_OCInitStruct;

   TIM_OCInitStruct.TIM_OCMode = TIM_OCMode_PWM1;
   TIM_OCInitStruct.TIM_OutputState = TIM_OutputState_Enable;
   TIM_OCInitStruct.TIM_OCPolarity = TIM_OCPolarity_High;
   TIM_OCInitStruct.TIM_Pulse = timPulse;
   TIM_OC1Init(TIM2, &TIM_OCInitStruct);
   TIM_OC1PreloadConfig(TIM2, TIM_OCPreload_Enable);

}

void pwm1Config(uint16_t timPulse){
   TIM_OCInitTypeDef TIM_OCInitStruct;

   TIM_OCInitStruct.TIM_OCMode = TIM_OCMode_PWM1;
   TIM_OCInitStruct.TIM_OutputState = TIM_OutputState_Enable;
   TIM_OCInitStruct.TIM_OCPolarity = TIM_OCPolarity_High;
   TIM_OCInitStruct.TIM_Pulse = timPulse;
   TIM_OC2Init(TIM2, &TIM_OCInitStruct);
   TIM_OC2PreloadConfig(TIM2, TIM_OCPreload_Enable);

}
void delay(uint32_t time){
   
   while(time--);


}

int main(){
   gpioConfig();
   timerConfig();

   
   
   while(1){
       pwmConfig(359);//0 derece
       delay(7200000);
       pwmConfig(480);//90 derece
       delay(7200000);
       pwmConfig(240);//180 derece
       delay(7200000);
		   pwm1Config(359);//0 derece
       delay(7200000);
       pwm1Config(480);//90 derece
       delay(7200000);
       pwm1Config(240);//180 derece
       delay(7200000);
   }



}
