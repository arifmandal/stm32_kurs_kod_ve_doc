#include "stm32f10x.h"                  // Device header
#include "stm32f10x_wwdg.h"             // Keil::Device:StdPeriph Drivers:WWDG


void gpioConfig(){
	
	GPIO_InitTypeDef GPIOInitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
	
  GPIOInitStructure.GPIO_Mode=GPIO_Mode_Out_PP;
	GPIOInitStructure.GPIO_Pin=GPIO_Pin_0;
	GPIOInitStructure.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOB,&GPIOInitStructure);

}

void WWDGConfig(){
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_WWDG,ENABLE);
	
	WWDG_DeInit();
	WWDG_SetPrescaler(WWDG_Prescaler_8);
	WWDG_SetWindowValue(120);
	WWDG_Enable(100);
	WWDG_EnableIT();
}

void NVICConfig(){
	
	NVIC_InitTypeDef NVICInitStructure;
	
	NVICInitStructure.NVIC_IRQChannel=WWDG_IRQn;
	NVICInitStructure.NVIC_IRQChannelCmd=ENABLE;
	NVICInitStructure.NVIC_IRQChannelPreemptionPriority=0;
	NVICInitStructure.NVIC_IRQChannelSubPriority=0;
	
	NVIC_Init(&NVICInitStructure);



}


void WWDG_IRQHandler(){
	
	WWDG_ClearFlag();
	WWDG_SetCounter(100);
	
	GPIOB->ODR ^=GPIO_Pin_0;

}

int main(){
	gpioConfig();
	WWDGConfig();
	NVICConfig();
	
	while(1){
		////
	
	
	}





}

/* 

TIME=(1000/24000000)*4096*PRESCALER*(WINDOW-COUNTER)
27.3 ms


*/

