#include "stm32f10x.h"                  // Device header
#include "stm32f10x_usart.h"            // Keil::Device:StdPeriph Drivers:USART

void gpioConfig(void);
void uartConfig(void);
void uartTransmit(char *string);

static char test[25]="ARIF MANDAL\r\n";
static uint16_t data=0;

void gpioConfig(){
	GPIO_InitTypeDef GPIOInitStructure;
	
	//TX->PA9 AND RX->PA10
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
	
	//TX
	GPIOInitStructure.GPIO_Mode=GPIO_Mode_AF_PP;
	GPIOInitStructure.GPIO_Pin=GPIO_Pin_9;
	GPIOInitStructure.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIOInitStructure);
	
	//RX
	GPIOInitStructure.GPIO_Mode=GPIO_Mode_IN_FLOATING;
	GPIOInitStructure.GPIO_Pin=GPIO_Pin_10;
	GPIO_Init(GPIOA,&GPIOInitStructure);
	
	//LED
	GPIOInitStructure.GPIO_Mode=GPIO_Mode_Out_PP;
	GPIOInitStructure.GPIO_Pin=GPIO_Pin_0;
	GPIOInitStructure.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOB,&GPIOInitStructure);

}

void uartConfig(){
	USART_InitTypeDef UARTInitStructure;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1,ENABLE);
	
	UARTInitStructure.USART_BaudRate=9600;
	UARTInitStructure.USART_HardwareFlowControl=USART_HardwareFlowControl_None;
	UARTInitStructure.USART_Mode=USART_Mode_Tx | USART_Mode_Rx;
	UARTInitStructure.USART_Parity=USART_Parity_No;
	UARTInitStructure.USART_StopBits=USART_StopBits_1;
	UARTInitStructure.USART_WordLength=USART_WordLength_8b;
	
	USART_Init(USART1,&UARTInitStructure);
	USART_Cmd(USART1,ENABLE);

}

void uartTransmit(char *string){
	while(*string){
		while(!(USART1->SR & 0x00000040));
		USART_SendData(USART1,*string);
		*string++;

	}
}


int main(){
	gpioConfig();
	uartConfig();
	
	
	while(1){
		//uartTransmit(test);
		data=USART_ReceiveData(USART1);
		
		if(data=='1'){
			GPIO_SetBits(GPIOB,GPIO_Pin_0);

		}if(data=='0'){
			GPIO_ResetBits(GPIOB,GPIO_Pin_0);
		}
		
	}




}

