#include "stm32f10x.h"                  // Device header
#include "stm32f10x_iwdg.h"             // Keil::Device:StdPeriph Drivers:IWDG


void gpioConfig(){
	GPIO_InitTypeDef GPIOInitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
	
	GPIOInitStructure.GPIO_Mode=GPIO_Mode_Out_PP;
	GPIOInitStructure.GPIO_Pin=GPIO_Pin_0;
	GPIOInitStructure.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOB,&GPIOInitStructure);
}

void delayUS(uint32_t time){
	uint32_t newTime=time*24;
	while(newTime--);
}

void IWDGConfig(){
	
	RCC_LSICmd(ENABLE);
	while(RCC_GetFlagStatus(RCC_FLAG_LSIRDY)==RESET){
	
	}
	
	IWDG_WriteAccessCmd(IWDG_WriteAccess_Enable);
	IWDG_SetPrescaler(IWDG_Prescaler_4);
	IWDG_SetReload(0xFFF);
	IWDG_ReloadCounter();
	IWDG_Enable();
	
}
int main(){
	gpioConfig();
	
	GPIO_ResetBits(GPIOB,GPIO_Pin_0);
	delayUS(300000);
	GPIO_SetBits(GPIOB,GPIO_Pin_0);
	IWDGConfig();
	
	
	while(1){
	////
	
	}



}

