#include "stm32f10x.h"                  // Device header
#include "stm32f10x_pwr.h"              // Keil::Device:StdPeriph Drivers:PWR


void gpioConfig(){
	
	GPIO_InitTypeDef GPIOInitStructure;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
	
	GPIOInitStructure.GPIO_Mode=GPIO_Mode_Out_PP;
	GPIOInitStructure.GPIO_Pin=GPIO_Pin_0;
	GPIOInitStructure.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOB,&GPIOInitStructure);
	
}

void delay(uint32_t time){
	while(time--);


}
int main(){
	gpioConfig();
	
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR,ENABLE);
	PWR_WakeUpPinCmd(ENABLE);// PA0-> STANDBY MODU PASIF EDECEK PIN
	
	
	while(1){
		
		for(int i=0; i<4; i++){// 4 adet blink islemi
			GPIO_SetBits(GPIOB,GPIO_Pin_0);
			delay(3600000);
			GPIO_ResetBits(GPIOB,GPIO_Pin_0);
			delay(3600000);
		
		}
		PWR_EnterSTANDBYMode();//standby modu aktif
	
	
	}




}


